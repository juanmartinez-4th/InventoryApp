// PROBLEMA: Fixed FOOTER tapa contenido del MAIN content
// FIX: LEER la altura del footer y pasársela al MARGIN-BOTTOM del contenido en MAIN
$(document).ready (function(){
    var newHeight = $("footer").css( "height" );
    $("main").css("margin-bottom", newHeight);
});

$(window).resize (function(){
    var newHeight = $("footer").css( "height" );
    $("main").css("margin-bottom", newHeight);
});
